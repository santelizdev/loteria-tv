# core/admin.py
from .admin_configs import (  # noqa: F401
    client,
    branch,
    device,
    provider,
    current_result,
    result_archive,
    transmission,
    animalito_result,
)
