// pwa/config.js
// Compatible: Android 8+ — sin arrow functions ni const/let
(function () {
  var isLocal =
    location.hostname === "localhost" ||
    location.hostname === "127.0.0.1" ||
    location.hostname.endsWith(".local");

  var API_BASE    = isLocal ? "http://127.0.0.1:8000" : "https://api.ssganador.lat";
  var WS_BASE     = isLocal ? "ws://127.0.0.1:8000"   : "wss://api.ssganador.lat";
  var CLIENT_LOGO = isLocal ? "" : "";  // pon aquí la URL del logo si aplica

  window.__APP_CONFIG__ = {
    API_BASE:    API_BASE,
    WS_BASE:     WS_BASE,
    CLIENT_LOGO: CLIENT_LOGO,
    isLocal:     isLocal,
  };
})();
